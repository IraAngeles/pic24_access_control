/*
 * File:   ME 1.c
 * Author: GL502VM-FY219T
 *
 * Created on March 22, 2019, 2:49 PM
 */

#include "xc.h"
#include "stdlib.h"
#include "stdio.h"
#include "time.h"
#include <ctype.h>
#define FCY 16000000UL    //needs to be defined first before libpic30.h
//#define FCY 4000000
#include "libpic30.h"
#include "string.h"

#pragma config FWDTEN=OFF
#pragma config JTAGEN=OFF
#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary Oscillator disabled)
#pragma config IOL1WAY = OFF             // IOLOCK One-Way Set Enable (Once set, the IOLOCK bit cannot be clj eared)
#pragma config OSCIOFNC = ON           // OSCO Pin Configuration (OSCO pin functions as clock output (CLKO))u
#pragma config I2C1SEL = PRI            // I2C1 Pin Select bit (Use default SCL////////////////////////////////////////////////////////////1/SDA1 pins for I2C1 )
#pragma config FCKSM=CSDCMD            // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
#pragma config FNOSC = FRCPLL           // Initial Oscillator Select (Fast RC Oscillator with Postscaler and PLL module (FRCPLL))
#pragma config IESO= OFF
#pragma config PLL96MHZ = ON            // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
#pragma config PLLDIV = DIV2             // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
#pragma config SOSCSEL=IO
#pragma config ICS = PGx2 

//#pragma config FWDTEN=OFF
//#pragma config JTAGEN=OFF
//#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary Oscillator disabled)
//#pragma config IOL1WAY = OFF             // IOLOCK One-Way Set Enable (Once set, the IOLOCK bit cannot be clj eared)
//#pragma config OSCIOFNC = ON           // OSCO Pin Configuration (OSCO pin functions as clock output (CLKO))u
//#pragma config I2C1SEL = PRI            // I2C1 Pin Select bit (Use default SCL////////////////////////////////////////////////////////////1/SDA1 pins for I2C1 )
//#pragma config FCKSM=CSDCMD            // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
//#pragma config FNOSC = FRCPLL           // Initial Oscillator Select (Fast RC Oscillator with Postscaler and PLL module (FRCPLL))
//#pragma config IESO= OFF
//#pragma config PLL96MHZ = ON            // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
//#pragma config PLLDIV = DIV2             // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
//#pragma config SOSCSEL=IO

#define DEBOUNCEMAX 100
#define button _RA0 //change
#define LED_2 _LATB14


//void __attribute__ ((interrupt)) _CNInterrupt(void);
//void __attribute__ ((interrupt, no_auto_psv)) _ADC1Interrupt(void);
//void __attribute__((__interrupt__, auto_psv)) _T1Interrupt(void);
size_t strlen(const char *s);
//void TimerInit(void);
//void ADC_init();
void delay_15 (void);
void delay340us (void);
void send4toLCD (int w);
void send8toLCD (int x);
void LCD (void);
void LCDcmd(int z);
void string (char* buf);
void newline (void);
void firstline (void);
void clear (void);
void cursor (void);
void initgamevar(void);

int u;
int w;
int x;
int y;
int z;
//keypad vars
int key=0;
int adcvalue;
//gamevars
int diff=0; //difficulty
int mode=0; //single or multiple
int score=0;
int digit1=0; //operand 1
int digit2=0; //operand 2
int operation=0; //operation
int result=0; //correct answer
int inputs[3] = {1,0,0}; //input answer
int answer=0; //inputed answer
int place;
int timelimit;
char buffer[15] = "";
char question[15] = "not working";
int seed=3;
int second=0;
int keypadpress=0;
int endgameflag = 0;
int wrongchoice[2];
int correctletter=4;
int letteranswer=4;
int counter;
int arraytoint(int* buf);

int main(void) {
AD1PCFG = 0xFDFF;  
TRISA = 0xffff;
TRISB = 0x9000;
LATB = 0xffff; 
LATA = 0x01;
LCD(); //initialize LCD
ADC_init(); //initialize ADC
//IEC0bits.AD1IE=1;//enable interrupt
//IFS0bits.AD1IF=0;//clear interrupt flag
//AD1CON1bits.ADON = 1; //turn on ADC
int press;
//start game mode
    gamestart:
    initgamevar();
    clear();
    LED_2=1;
    

//    string("   WELCOME TO");
//    newline();
    string(" ARIANE'S GAME");
    
    while (1){
//        __delay_ms(500);
       LED_2=0; 
       __delay_ms(500);
       LED_2=1; 
       __delay_ms(500);    
    }
    //!button not pressed
    //button ==0 => unpressed
        while(button){ //while push button not pressed
           
        }
        if(button){
             press =0;
        }
        else if(!button){
             press =1;
        }

      return 0;
}
void number (int buff){
    int ones;
    int tens;
    int hundreds;
    int thousands;
    
    thousands = buff/1000;
    
    hundreds = buff - thousands*1000;
    hundreds = hundreds/100;
    
    tens = buff - thousands*1000;
    tens = tens - hundreds*100;
    tens = tens/10;
    
    ones = buff - thousands*1000;
    ones = ones - hundreds*100;
    ones = ones - tens*10;
    
    thousands = thousands | 0x30;
    hundreds = hundreds | 0x30;
    tens = tens | 0x30;
    ones = ones | 0x30;
    
    LCDcmd(thousands);
    LCDcmd(hundreds);
    LCDcmd(tens);
    LCDcmd(ones);
    
    return;
}
void ADC_init(){
    //AD1PCFG = 0xFDFF;    //AN9 IS SET TO HAVE ANALOG INPUT
    AD1CON1=0x20E6;
    AD1CON2=0x0000;
    AD1CON3=0x0201;
    AD1CHS=0x0009;
    AD1CSSL=0x0000;  
    //setup ADC configuration bits and TRISB
}
void delay_15 (void){ //15ms
    int k=0;
    while (k < 1880)
    k = k + 1;
    return;
}
void delay340us (void){ //340us
    int k=0;
    while (k < 1880)
    k = k + 1;
    return;
}
//void send4toLCD (int w){
//    
//    LATB = 0x0000;
//    delay_15();
//    delay_15();
//    delay_15();
//    Nop();
//    //w=w<<8;        
//    w = w & 0x000F;
//    w = w | 0x0020;
//    w = LATB | w;
//    LATB = w;
//
//    delay_15();
//    LATBbits.LATB5 = 0;
//    delay_15();
//    return;
//}
//void send8toLCD (int x){
//    int y;
//    LATB = 0x0000;
//    delay340us();
//    delay340us();
//    delay340us();
//    Nop();
//    //x=x<<4;  
//    y = x & 0x00F0;
//    y = y >> 4;
//    y = y | 0x0020;
//    y = LATB | y;
//    LATB = y;
//    delay340us();
//    LATBbits.LATB5 = 0;
//    
//    
//    LATB = 0x0000;
//    delay340us();
//    Nop();
//    //x=x>>4;       
//    y = x & 0x000F;
//    y = y | 0x0020;
//    y = LATB | y;
//    LATB = y;
//    delay340us();
//    LATBbits.LATB5 = 0;
//    delay340us();
//    return;
//}
void LCD (void) {       
    delay_15();
    delay_15();
    delay_15();
    
    w = 0x3;
    send4toLCD(w);

    
    w = 0x3;
    send4toLCD(w);

    
    w = 0x3;
    send4toLCD(w);

    
    ///////////////
    
    w = 0x2;
    send4toLCD(w);
  
    
    ////////////////////
    
    //Function set 
    x = 0x28;
    send8toLCD(x); 
   
    
    //Display off
    x = 0x08;
    send8toLCD(x);
    
    
    //Clear Display
    x = 0x01;
    send8toLCD(x);
    
  
    //Entry mode
    x = 0x06;
    send8toLCD(x);
  
    
    //Display On
    x = 0x0C;
    send8toLCD(x);
    
    return;
    
}
//void LCDcmd(int z){
//    int u;
//    LATB = 0x0000;
//    Nop();
//    delay340us();
//    delay340us();
//    //x=x<<4;  
//    u = z & 0x00F0;
//    u = u >> 4;
//    u = u | 0x0030;
//    LATB = u;
//    delay340us();
//    delay340us();
//    LATBbits.LATB5 = 0;
//    delay340us();
//    delay340us();
//    
//    Nop();
//    //x=x<<4;       
//    u = z & 0x000F;
//    u = u | 0x0030;    
//    LATB = u;
//    delay340us();
//    LATBbits.LATB5 = 0;
//    delay340us();
//    delay340us();
//    LATBbits.LATB4 = 0;
//    delay340us();
//    delay340us();
//    delay340us();
//    delay340us();
//    return;    
//}
void string (char* buf){
    int a = 0;
    int b = 0;
    int c = 0;
    
    a = strlen(buf);
    
    while (b < a){
        c = buf[b];
        b = b+1;
        LCDcmd(c);
    }   
    return;
}
void firstline (void){
    send8toLCD(0x80);
}
void newline (void){
    send8toLCD(0xC0);
}
void clear (void){
    send8toLCD(0x01);
}
void cursor (void){
    send8toLCD(0xE);
}

//void __attribute__ ((interrupt, no_auto_psv)) _ADC1Interrupt(void){
//IEC0bits.AD1IE=0;//Disable interrupt
//IFS0bits.AD1IF=0;//Clear flag
//adcvalue = ADC1BUF0; //Copy ADC output to adcvalue
//IEC0bits.AD1IE=1;//Enable interrupt
//IFS0bits.AD1IF=0;//Clear flag
//}
//void __attribute__((interrupt)) _CNInterrupt(void){
//    int deb_ctr = 0;
//    
//     LATBbits.LATB7 = 1;
//    //delay()
//    LATBbits.LATB8 = 1;
//    //delay();
//    LATBbits.LATB9 = 0;
//    //delay();
//    if(!PORTAbits.RA1){
//        while((!PORTAbits.RA1)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//        if(deb_ctr == DEBOUNCEMAX){
//            key=3;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//    if(!PORTAbits.RA2){
//        while((!PORTAbits.RA2)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//         if(deb_ctr == DEBOUNCEMAX){
//            key=6;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//     if(!PORTAbits.RA3){
//        while((!PORTAbits.RA3)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//       if(deb_ctr == DEBOUNCEMAX){
//            key=9;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//     if(!PORTAbits.RA4){
//        while((!PORTAbits.RA4)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//        if(deb_ctr == DEBOUNCEMAX){
//            key=12;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//    LATBbits.LATB7 = 0;
//    LATBbits.LATB8 = 1;
//    LATBbits.LATB9 = 1;
//    
//    if(!PORTAbits.RA1){
//        while((!PORTAbits.RA1)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//        if(deb_ctr == DEBOUNCEMAX){
//            key=1;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//      if(!PORTAbits.RA2){
//        while((!PORTAbits.RA2)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//         if(deb_ctr == DEBOUNCEMAX){
//            key=4;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//      if(!PORTAbits.RA3){
//        while((!PORTAbits.RA3)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//       if(deb_ctr == DEBOUNCEMAX){
//            key=7;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//     if(!PORTAbits.RA4){
//        while((!PORTAbits.RA4)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//        if(deb_ctr == DEBOUNCEMAX){
//            key=10;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//    
//    LATBbits.LATB7 = 1;
//    LATBbits.LATB8 = 0;
//    LATBbits.LATB9 = 1;
//    //delay();
//    
//    if(!PORTAbits.RA1){
//        while((!PORTAbits.RA1)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//       if(deb_ctr == DEBOUNCEMAX){
//            key=2;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//     if(!PORTAbits.RA2){
//        while((!PORTAbits.RA2)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//         if(deb_ctr == DEBOUNCEMAX){
//            key=5;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//      if(!PORTAbits.RA3){
//        while((!PORTAbits.RA3)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//       if(deb_ctr == DEBOUNCEMAX){
//            key=8;
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//     if(!PORTAbits.RA4){
//        while((!PORTAbits.RA4)&&(deb_ctr<DEBOUNCEMAX)){
//            deb_ctr++;
//        }
//        
//        if(deb_ctr == DEBOUNCEMAX){
//            key=11; //for 0
//        }
//        else{
//            key=0;
//        }
//        goto back;
//    }
//   LATBbits.LATB7 = 1;
//    LATBbits.LATB8 = 1;
//    LATBbits.LATB9 = 0;
//   
//    
//    back:
//        IFS1bits.CNIF = 0; //clear IRQ flag
//        LATBbits.LATB7 = 0; //pull down all
//        LATBbits.LATB8 = 0;
//        LATBbits.LATB9 = 0;
//        keypadpress=1;
//        __delay_ms(1);
//}
//void __attribute__((__interrupt__, auto_psv)) _T1Interrupt(void)
//  {
//
//   IFS0bits.T1IF = 0;   //reset the interrupt flag 
//   second =second+1;
//       if(second == timelimit)
//       {
//             second = 0;
//             endgameflag = 1;
//      }
// }
//void TimerInit(void)
//{
//   IEC0bits.T1IE = 0;      /* Disable Timer1 interrupt */
//    T1CON = 0;              /* Disable Timer */
//    T1CONbits.TCS = 0;      /* Instruction cycle clock */
//    T1CONbits.TGATE = 0;    /* Disable Gated Timer mode */
//    T1CONbits.TCKPS = 0b11; /* Select 1:256 Prescaler */
//    T1CONbits.TSYNC = 1;    /* Synchronize external clock input */
//    TMR1 = 0;               /* Clear timer register */
//    PR1 = 60000;  /* Load the timer reset count value */
//    IPC0bits.T1IP = 0x04;   /* Set Timer1 Interrupt Priority Level */
//    IFS0bits.T1IF = 0;      /* Clear Timer1 Interrupt Flag */
//    IEC0bits.T1IE = 1;      /* Enable Timer1 interrupt */
//    T1CONbits.TON = 1;      /* Start Timer */
//
// }
void initgamevar(void){
        score=0;
        second=0;
        keypadpress=0;
        endgameflag = 0;
        wrongchoice[0]=4;
        wrongchoice[1]=4;
        correctletter=4;
        letteranswer=4;
        diff=0;
        answer=100;
        LED_2 =1;
        endgameflag=0;
        timelimit = 0;
        mode=0;
        inputs[0] = 1;
        inputs[1] = 0;
        inputs[2] = 0;
}
int arraytoint(int* buf){
    int integerval = 0;
    integerval = buf[0]*((buf[1]*10)+buf[2]); //sign , tens, ones
    return integerval;
}

void send4toLCD (int w){
    
    LATB = 0x0000;
    Nop();
    //w=w<<8;        
    w = w & 0x000F;
    w = w | 0x0020;
    w = LATB | w;
    LATB = w;

    delay_15();
    LATBbits.LATB5 = 0;
    return;
}
void send8toLCD (int x){
    int y;
    LATB = 0x0000;
    Nop();
    //x=x<<4;  
    y = x & 0x00F0;
    y = y >> 4;
    y = y | 0x0020;
    y = LATB | y;
    LATB = y;
    delay340us();
    LATBbits.LATB5 = 0;
    
    
    LATB = 0x0000;
    Nop();
    //x=x>>4;       
    y = x & 0x000F;
    y = y | 0x0020;
    y = LATB | y;
    LATB = y;
    delay340us();
    LATBbits.LATB5 = 0;
    return;
}

void LCDcmd(int z){
    int u;
    LATB = 0x0000;
    Nop();
    //x=x<<4;  
    u = z & 0x00F0;
    u = u >> 4;
    u = u | 0x0030;
    LATB = u;
    delay340us();
    LATBbits.LATB5 = 0;
    
    
    Nop();
    //x=x<<4;       
    u = z & 0x000F;
    u = u | 0x0030;    
    LATB = u;
    delay340us();
    LATBbits.LATB5 = 0;
    LATBbits.LATB4 = 0;
    return;    
}

