#include "xc.h"
#define FCY 4000000
#include "libpic30.h"
#include "string.h"

#pragma config FWDTEN=OFF
#pragma config JTAGEN=OFF
#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary Oscillator disabled)
#pragma config IOL1WAY = OFF             // IOLOCK One-Way Set Enable (Once set, the IOLOCK bit cannot be clj eared)
#pragma config OSCIOFNC = ON           // OSCO Pin Configuration (OSCO pin functions as clock output (CLKO))u
#pragma config I2C1SEL = PRI            // I2C1 Pin Select bit (Use default SCL////////////////////////////////////////////////////////////1/SDA1 pins for I2C1 )
#pragma config FCKSM=CSDCMD            // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
#pragma config FNOSC = FRCPLL           // Initial Oscillator Select (Fast RC Oscillator with Postscaler and PLL module (FRCPLL))
#pragma config IESO= OFF
#pragma config PLL96MHZ = ON            // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
#pragma config PLLDIV = DIV2             // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
#pragma config SOSCSEL=IO

#define WRITE_ADDR 0x0F
#define READ_ADDR 0x0B
#define EEPROM_slave_address 0xA0
#define I2C_Flag _MI2C1IF
#define I2C_EN _MI2C1IE

void Nop () {
    return;
}

void delay_15 (void){ //15ms
    int k=0;
    while (k < 1880)
    k = k + 1;
    return;
}

void delay340us (void){ //340us
    int k=0;
    while (k < 1880)
    k = k + 1;
    return;
}

void send4toLCD (int w){
    
    LATB = 0x0000;
    Nop();
    //w=w<<8;        
    w = w & 0x000F;
    w = w | 0x0020;
    w = LATB | w;
    LATB = w;

    delay_15();
    LATBbits.LATB5 = 0;
    return;
}

void send8toLCD (int x){
    int y;
    LATB = 0x0000;
    Nop();
    //x=x<<4;  
    y = x & 0x00F0;
    y = y >> 4;
    y = y | 0x0020;
    y = LATB | y;
    LATB = y;
    delay340us();
    LATBbits.LATB5 = 0;

    LATB = 0x0000;
    Nop();
    //x=x>>4;       
    y = x & 0x000F;
    y = y | 0x0020;
    y = LATB | y;
    LATB = y;
    delay340us();
    LATBbits.LATB5 = 0;
    return;
}

void LCD_init (void) {       
    delay_15();
    delay_15();
    delay_15();
    
    int w;
    int x;
   
    w = 0x3;
    send4toLCD(w);   
    w = 0x3;
    send4toLCD(w);
    w = 0x3;
    send4toLCD(w);
    w = 0x2;
    send4toLCD(w);
    //Function set 
    x = 0x28;
    send8toLCD(x);  
    //Display off
    x = 0x08;
    send8toLCD(x);
    //Clear Display
    x = 0x01;
    send8toLCD(x);
    //Entry mode
    x = 0x06;
    send8toLCD(x);
    //Display On
    x = 0x0C;
    send8toLCD(x);
    
    return;   
}

void LCDcmd(int z){
    int u;
    LATB = 0x0000;
    Nop();
    //x=x<<4;  
    u = z & 0x00F0;
    u = u >> 4;
    u = u | 0x0030;
    LATB = u;
    delay340us();
    LATBbits.LATB5 = 0; 
    Nop();
    //x=x<<4;       
    u = z & 0x000F;
    u = u | 0x0030;    
    LATB = u;
    delay340us();
    LATBbits.LATB5 = 0;
    LATBbits.LATB4 = 0;
    return;    
}

void string (char* buf){
    int a = 0;
    int b = 0;
    int c = 0;
    
    a = strlen(buf);
    
    while (b < a){
        c = buf[b];
        b = b+1;
        LCDcmd(c);
    }   
    return;
}

void firstline (void){
    send8toLCD(0x80);
}

// Initialize I2C module
void I2C_init(void) 
{
    TRISA = 0xFFFF; // set SCL and SDA pins as inputs
    TRISB = 0;
// I2C1BRG
    I2C1BRG = 0x9;
// I2C1CON
    I2C1CON = 0x2B80;
    I2C2CON = 0;
// IEC1
    I2C_EN = 1;
    I2C_Flag = 0;
// Enable I2C after configuration
    I2C1CONbits.I2CEN = 1;

}

// i2c_Wait - wait for I2C transfer to finish
void I2C_Wait(void){
    while (!I2C_Flag);
	I2C_Flag = 0;
}

// Send start bit sequence
void I2C_start(void)
{
// Set Start Condition Enabled Bit
    I2C1CONbits.SEN=1;
// Wait for operation to finish by checking interrupt flag
    I2C_Wait();
// Clear interrupt flag
}

// Send repeated start bit sequence
void I2C_restart(void)
{
// Set Repeated Start Condition Enabled bit
    I2C1CONbits.RSEN=1;
// Wait for operation to finish by checking interrupt flag
    I2C_Wait();
// Clear interrupt flag
}

// Send stop bit sequence
void I2C_stop(void)
{
// Set Stop Condition Enabled bit
    I2C1CONbits.PEN=1;
// Wait for operation to finish by checking interrupt flag
    I2C_Wait();
// Clear interrupt flag
}

// Send ACK bit sequence
void I2C_ack(void)
{
// Set Acknowledge Data bit
    I2C1CONbits.ACKDT=0;
// Set Acknowledge Sequence Enabled bit
    I2C1CONbits.ACKEN=1;
// Wait for operation to finish by checking interrupt flag
    I2C_Wait();
// Clear interrupt flag
}

// Send NACK bit sequence
void I2C_nack(void)
{
// Set Acknowledge Data bit
    I2C1CONbits.ACKDT=1;
// Set Acknowledge Sequence Enabled bit
    I2C1CONbits.ACKEN=1;
// Wait for operation to finish by checking interrupt flag
    I2C_Wait();
// Clear interrupt flag
}

// Transfer one byte sequence
int I2C_write(unsigned char Byte)
{
// Write byte to transmit buffer register
    I2C1TRN = Byte;
// Wait for operation to finish by checking interrupt flag
    I2C_Wait();
// Return Acknowledge bit received
    return I2C2STATbits.ACKSTAT;
}

// Receive one byte sequence
unsigned char I2C_read(void)
{
    char i2cReadData;
// Set Receive Enable bit
    I2C1CONbits.RCEN=1;
// Wait for operation to finish by checking interrupt flag
    I2C_Wait();
    i2cReadData = I2C1RCV;
// Clear interrupt flag
// Return receive buffer contents
    return i2cReadData;
}

// EEPROM write sequence
void EEPROM_write(unsigned int waddr, unsigned char wdata)
{
// Start I2C communication
I2C_start();

// Send I2C EEPROM slave address with write command, wait if device is not available
while(I2C_write(EEPROM_slave_address + 0)){
    I2C_restart();
}

// Send address, high byte then low byte
I2C_write(waddr>>8);
I2C_write(waddr);

// Send data
I2C_write(wdata);

// Stop I2C communication
I2C_stop();
}

// EEPROM read sequence
unsigned EEPROM_read(unsigned int raddr)
{
    unsigned char Byte = 0;

// Start I2C communication
I2C_start();

// Send I2C EEPROM slave address with write command, wait if device is not available
while(I2C_write(EEPROM_slave_address + 0)){
    I2C_restart();
}

// Send address, high byte then low byte
I2C_write(raddr>>8);
I2C_write(raddr);

// Send repeated start
I2C_restart();

// Send I2C EEPROM slave address with read command
I2C_write(EEPROM_slave_address + 1);

// Store data from buffer
Byte = I2C_read();

// Send NACK
I2C_nack();

// Stop I2C communication
I2C_stop();

return Byte;

}

int main(void)
{
    char buffer[17] = {NULL};
    char SN[9] = {50,48,49,50,54,52,54,50,57}; //201264629 in ASCII
    char buffer2[17] = {NULL};
    int counter = 0;
// Initialize I2C peripheral
    I2C_init();
// Initialize LCD
    LCD_init();
//Write student number to WRITE_ADDR
    while (counter < 9) {
        EEPROM_write(WRITE_ADDR + counter,SN[counter]);
        counter++; 
    }
    sprintf(buffer,"%s",SN);
    string(buffer);
// Read 16 bytes from READ_ADDR
    for(counter = 0; counter >= 15; counter++) {
        buffer2[counter] = EEPROM_read(READ_ADDR + counter);
    }
//// Display 16 bytes on LCD
    while(1) {
        sprintf(buffer,"%s",buffer2);
        string(buffer);
    }

    return 0;
}
