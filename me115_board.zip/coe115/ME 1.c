/*
 * File:   ME 1.c
 * Author: GL502VM-FY219T
 *
 * Created on March 22, 2019, 2:49 PM
 */

#include "xc.h"
#include "stdlib.h"
#include "stdio.h"
#include "time.h"
#include <ctype.h>
#define FCY 16000000UL    //needs to be defined first before libpic30.h
//#define FCY 4000000
#include "libpic30.h"
#include "string.h"

#pragma config FWDTEN=OFF
#pragma config JTAGEN=OFF
#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary Oscillator disabled)
#pragma config IOL1WAY = OFF             // IOLOCK One-Way Set Enable (Once set, the IOLOCK bit cannot be clj eared)
#pragma config OSCIOFNC = ON           // OSCO Pin Configuration (OSCO pin functions as clock output (CLKO))u
#pragma config I2C1SEL = PRI            // I2C1 Pin Select bit (Use default SCL////////////////////////////////////////////////////////////1/SDA1 pins for I2C1 )
#pragma config FCKSM=CSDCMD            // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
#pragma config FNOSC = FRCPLL           // Initial Oscillator Select (Fast RC Oscillator with Postscaler and PLL module (FRCPLL))
#pragma config IESO= OFF
#pragma config PLL96MHZ = ON            // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
#pragma config PLLDIV = DIV2             // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
#pragma config SOSCSEL=IO
#pragma config ICS = PGx2 

//#pragma config FWDTEN=OFF
//#pragma config JTAGEN=OFF
//#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary Oscillator disabled)
//#pragma config IOL1WAY = OFF             // IOLOCK One-Way Set Enable (Once set, the IOLOCK bit cannot be clj eared)
//#pragma config OSCIOFNC = ON           // OSCO Pin Configuration (OSCO pin functions as clock output (CLKO))u
//#pragma config I2C1SEL = PRI            // I2C1 Pin Select bit (Use default SCL////////////////////////////////////////////////////////////1/SDA1 pins for I2C1 )
//#pragma config FCKSM=CSDCMD            // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
//#pragma config FNOSC = FRCPLL           // Initial Oscillator Select (Fast RC Oscillator with Postscaler and PLL module (FRCPLL))
//#pragma config IESO= OFF
//#pragma config PLL96MHZ = ON            // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
//#pragma config PLLDIV = DIV2             // 96MHz PLL Startup Select (96 MHz PLL Startup is enabled automatically on start-up)
//#pragma config SOSCSEL=IO

#define DEBOUNCEMAX 100
#define button _RA0 //change
#define LED_2 _LATB14


//void __attribute__ ((interrupt)) _CNInterrupt(void);
//void __attribute__ ((interrupt, no_auto_psv)) _ADC1Interrupt(void);
//void __attribute__((__interrupt__, auto_psv)) _T1Interrupt(void);
size_t strlen(const char *s);
void TimerInit(void);
void ADC_init();
void delay_15 (void);
void delay340us (void);
void send4toLCD (int w);
void send8toLCD (int x);
void LCD (void);
void LCDcmd(int z);
void string (char* buf);
void newline (void);
void firstline (void);
void clear (void);
void cursor (void);
void initgamevar(void);

int u;
int w;
int x;
int y;
int z;
//keypad vars
int key=0;
int adcvalue;
//gamevars
int diff=0; //difficulty
int mode=0; //single or multiple
int score=0;
int digit1=0; //operand 1
int digit2=0; //operand 2
int operation=0; //operation
int result=0; //correct answer
int inputs[3] = {1,0,0}; //input answer
int answer=0; //inputed answer
int place;
int timelimit;
char buffer[15] = "";
char question[15] = "not working";
int seed=3;
int second=0;
int keypadpress=0;
int endgameflag = 0;
int wrongchoice[2];
int correctletter=4;
int letteranswer=4;
int counter;
int arraytoint(int* buf);

int main(void) {
AD1PCFG = 0xFDFF;  
TRISA = 0xffff;
TRISB = 0x9000;
LATB = 0xffff; 
LATA = 0x01;
LCD(); //initialize LCD
ADC_init(); //initialize ADC
//IEC0bits.AD1IE=1;//enable interrupt
//IFS0bits.AD1IF=0;//clear interrupt flag
//AD1CON1bits.ADON = 1; //turn on ADC
int press;
//start game mode
    gamestart:
    initgamevar();
    clear();
    LED_2=1;
    

    string("   WELCOME TO");
    newline();
    string(" ARIANE'S GAME");
    
    while (1){
        __delay_ms(5000);
       LED_2=0; 
       __delay_ms(5000);
       LED_2=1; 
       __delay_ms(5000);    
    }
    //!button not pressed
    //button ==0 => unpressed
        while(button){ //while push button not pressed
           
        }
        if(button){
             press =0;
        }
        else if(!button){
             press =1;
        }

    clear();
    string("   GAME MODE");
    newline();
    string("     SELECT");
    __delay_ms(200);
    clear();
    string("1-Key Input Mode");
    newline();
    string("2-Multi Choice");
     __delay_ms(10);
   CNPU1 = CNPU1 | 0x0009; // Bit 0 and 3
    CNPU2 = CNPU2 | 0x6000; // Bit 13 and 14
    
    CNEN1 = CNEN1 | 0x0009;
    CNEN2 = CNEN2 | 0x6000; 
        IEC1bits.CNIE = 1;
        IFS1bits.CNIF = 0;
        LATBbits.LATB7 = 0; //pull down all
        LATBbits.LATB8 = 0;
        LATBbits.LATB9 = 0;
    while(1){
        IEC1bits.CNIE = 0;         
        LATBbits.LATB7 = 0;
        LATBbits.LATB8 = 0;
        LATBbits.LATB9 = 0;
        IEC1bits.CNIE = 1;
       if(key==1){
           newline();
            mode =1; //Key input mode
            key=0;
            goto difficulty;
        }
       else if(key==2){
            mode =2; //multi choice
            key=0;
            goto difficulty;
        }
       else{}
    }
        difficulty: //sets difficulty
        diff=0;
    while(1){//while push button not 
        if(adcvalue<341){ //if adc value < thresh
            if(diff!=1){
                clear();
               if(mode==1){
               string("Game Mode 1");
               }
               if(mode==2){
               string("Game Mode 2");
               }
               newline();
               string("Difficulty: Easy");
            }
            timelimit =5; //5 seconds
          diff=1;//easy
        }
        else if(adcvalue>=341 && adcvalue< 682){ //if adc value < thresh
            if(diff!=2){
                clear();
                if(mode==1){
                string("Game Mode 1");
                }
                if(mode==2){
                string("Game Mode 2");
                }
                newline();
                string("Difficulty: Ave");
            }
        
        timelimit = 8;
        diff=2;//meh
        }
        else if(adcvalue>=682){ //if adc value < thresh
            if(diff!=3){
                clear();
                if(mode==1){
                string("Game Mode 1");
                }
                if(mode==2){
                string("Game Mode 2");
                }
                newline();
                string("Difficulty: Hard");
            }
        diff=3;//hard
        timelimit=100;
        }
        if(!button) // unpressed pressed
        {
          __delay_ms(300);
         goto gameproper;   
        }
        
     }
         gameproper:
         if(!button){
         press =0;
        }
        else if(button){
         press =1;
         }
        if (mode==1){
             TimerInit();
             goto gamemode1;
         }
         else if (mode==2){    
            TimerInit();
             goto gamemode2;
         }
         else{}
         
         ////////////////GAME PROPER//////////////////////////////
         ////////////////GAME MODE 1//////////////////////////////
         
         gamemode1:
         seed=seed+1;
         while(1){  
             clear();
             buffer[0]= 0;
             keypadpress=0;
             key=0;
            inputs[0] = 1;
            inputs[1] = 0;
            inputs[2] = 0;
             if(endgameflag==1){
                endgameflag=0;
                goto gameover;
             }
             srand(seed);
             digit1 = (rand() % 19) - 9; //gets random value for the digits
             digit2 = (rand() % 19) - 9; 
             place=0xC3;
             if (diff ==1){ //checks if easy difficulty 
                 operation = rand()%1; // 0
             }
             else if (diff ==2){ //checks if ave difficulty
                 operation = rand()%2; // 2 values to choose from, 0 and 1
             }
             else if (diff ==3){ //checks if hard difficulty
                 operation = rand()%3; // 0,1, 2
             }
             else{}
             firstline();
             if (operation==0){ //addition
                 sprintf(question,"Q: %d + %d",digit1, digit2);
                  result = digit1+digit2;
             }
             else if (operation==1){//subtraction
                 sprintf(question,"Q: %d - %d",digit1, digit2);
                 result = digit1-digit2;
             }
             else if (operation==2){// multiplication
                 sprintf(question,"Q: %d * %d",digit1, digit2);
                  result = digit1*digit2;
             }
             else{}
             clear();
             firstline();
             string(question);
             newline();
             string("A:");
             send8toLCD(place); 
             cursor();
             __delay_ms(50);
             while(1){ //key input game
                 if(endgameflag==1){
                    endgameflag=0;
                    goto gameover;
                    }
                    if(keypadpress==1){ //checks if keypad is pressed
                        keypadpress=0; //sets keypad flag to 0
                        if(key==12){ //negative #button
                            if(place == 0xC3){
                                send8toLCD(place); //prints at certain ddram
                                string("-");
                                place = place + 1; //moves one box to the right
                                send8toLCD(place); 
                                cursor();
                                inputs[0] = -1;
                            }
                            else{}
                        }
                        else if(key==10){ //backspace *button
                            if(place>0xC3 &&place<=0xCF ){
                                place = place - 1;
                                send8toLCD(place); //prints at certain ddram   
                                string(" ");
                                send8toLCD(place); 
                                cursor();
                                if(place==0xC4&&inputs[0]==1){//storing positive values at first box eg. 12_
                                    inputs[2] = inputs[1]; // moving from tens place to ones place
                                    inputs[1] = 0;//tens place is set to 0
                                }
                                if(place==0xC4 && inputs[0]==-1){// if negative single digit eg. -3_
                                    inputs[2] = 0;//ones
                                    inputs[1] = 0;
                                }
                                if(place==0xC5 && inputs[0]==-1){// if negative 2 digits eg -21_
                                    inputs[2] = inputs[1]; // moving from tens place to ones place
                                    inputs[1] = 0;//ones
                                }
                            }
                            if(place==0xC3){
                                send8toLCD(place); //prints at certain ddram
                                string(" ");
                                send8toLCD(place); 
                                cursor();
                                    inputs[0] = 1; //sign
                                    inputs[1] = 0;
                                    inputs[2] = 0;
                            }
                        }
                        else{
                            if(place>=0xC3 &&place<=0xCF){
                                sprintf(buffer,"%d",key);
                                send8toLCD(place); //prints at certain ddram
                                string(buffer);
                                
                                if(place==0xC3){//storing positive values at first box eg. 1_
                                    inputs[0] = 1; ///positive
                                    inputs[2] = key;//ones
                                    
                                }
                                if(place==0xC4&&inputs[0]==1){//storing positive values at first box eg. 12_
                                    inputs[1] = inputs[2]; // moving from ones place to tens place
                                    inputs[2] = key;//ones
                                }
                                if(place==0xC4 && inputs[0]==-1){// if negative single digit eg. -3_
                                    inputs[2] = key;//ones
                                    inputs[1] = 0;
                                }
                                if(place==0xC5 && inputs[0]==-1){// if negative 2 digits eg -21_
                                    inputs[1] = inputs[2]; // moving from ones place to tens place
                                    inputs[2] = key;//ones
                                }
                                
                                if(place!=0xCF){
                                    place = place + 1; //moves one box to the right
                                }
                                send8toLCD(place); 
                                cursor();
                            }
                        }
                    }
                    if (!button){
                        if((place>0xC6 && inputs[0]==-1) || (place>0xC5 && inputs[0] == 1 )){//if more than 2 place values
                            answer=100;
                        }
                        else{//positive single digit
                            answer = arraytoint(inputs);
                        }
                         clear();
                         sprintf(buffer,"%d , %d, %d",inputs[0],inputs[1],inputs[2]);
                        // sprintf(buffer,"%d",answer);
                         string(buffer);
                            __delay_ms(100);
                        goto check;
                    }
             }
         } 
         ////////// if timer is done go to game over window
        ////////////////GAME MODE 2//////////////////////////////
         gamemode2:
         seed=seed+1;
         while(1){  
             clear();
             buffer[0]=0;
             if(endgameflag==1){//checks gameover flag
                endgameflag=0;
                goto gameover;
            }
             //////////////SETTING UP RANDOM VALUES/////////////////////
             srand(seed);
             digit1 = (rand() % 19) - 9; //gets random value for the digits
             digit2 = (rand() % 19) - 9; 
             correctletter = rand()%3;
             if (diff ==1){ //checks if easy difficulty 
                 operation = rand()%1; // 0
             }
             else if (diff ==2){ //checks if ave difficulty
                 operation = rand()%2; // 2 values to choose from, 0 and 1
             }
             else { //checks if hard difficulty
                 operation = rand()%3; // 0,1, 2
             }
             //////////////////////////////////////////////////////////////
             /////////////////////////////////////////////////////////////
             if (operation==0){ //addition
                 sprintf(question,"Q: %d + %d",digit1, digit2);
                  result = digit1+digit2;
                   wrongchoice[0] = (rand() % 19) - 9;
                   wrongchoice[1] = (rand() % 19) - 9;
             }
             else if (operation==1){//subtraction
                 sprintf(question,"Q: %d - %d",digit1, digit2);
                 result = digit1-digit2;
                  wrongchoice[0] = (rand() % 37) - 9;
                  wrongchoice[1] = (rand() % 37) - 9;
             }
             else{// multiplication
                 sprintf(question,"Q: %d * %d",digit1, digit2);
                  result = digit1*digit2;
                   wrongchoice[0] = (rand() % 163) - 81;
                   wrongchoice[1] = (rand() % 163) - 81;
             }
             while(1){ // makes sure wrong choices are not the same as the correct choice
                 if(wrongchoice[0] == result){ //if one of the wrong choices is the same as the correct choice
                     if(operation==3){ // if multiplication, more choices
                         wrongchoice[0] = (rand() % 163) - 81;
                     }
                     else{
                     wrongchoice[0] = (rand() % 19) - 9;
                     }
                 }
                 if( wrongchoice[1] == result){ //if one of the wrong choices is the same as the correct choice
                     if(operation==3){
                         wrongchoice[1] = (rand() % 163) - 81;
                     }
                     else{
                     wrongchoice[1] = (rand() % 19) - 9;
                     }
                 }
                 if (wrongchoice[1] == wrongchoice[0]){ //if wrong choices are the same
                     if(operation==3){
                         wrongchoice[1] = (rand() % 163) - 81;
                     }
                     else{
                     wrongchoice[1] = (rand() % 19) - 9;
                     }
                 }
                 if(wrongchoice[1] != result && wrongchoice[0] != result && wrongchoice[1] != wrongchoice[0]){
                         goto print; //proceed if none of the choices are the same
                 }
            }
             print: // prints choices
                clear();
                firstline();
                string(question);
                newline();
             if(correctletter==0){ //correct answer a
                sprintf(buffer,"a.%d",result);
                send8toLCD(0xC0); 
                string(buffer);
                sprintf(buffer,"b.%d", wrongchoice[0]);
                send8toLCD(0xC5); 
                string(buffer);
                sprintf(buffer,"c.%d",wrongchoice[1]);
                send8toLCD(0xCB); 
                string(buffer);
             }
             else if(correctletter==1){ //correct answer b
                sprintf(buffer,"a.%d",wrongchoice[0]);
                send8toLCD(0xC0); 
                string(buffer);
                sprintf(buffer,"b.%d", result);
                send8toLCD(0xC5); 
                string(buffer);
                sprintf(buffer,"c.%d",wrongchoice[1]);
                send8toLCD(0xCB); 
                string(buffer);
             }
             else{ //correct answer c
                sprintf(buffer,"a.%d",wrongchoice[0]);
                send8toLCD(0xC0); 
                string(buffer);
                sprintf(buffer,"b.%d", wrongchoice[1]);
                send8toLCD(0xC5); 
                string(buffer);
                sprintf(buffer,"c.%d",result);
                send8toLCD(0xCB); 
                string(buffer);
             }
             
             while(1){ //not pressed
                 if(endgameflag==1){
                    endgameflag=0;
                    goto gameover;
                    }
              
                 if(adcvalue<341){ // letter a
                        send8toLCD(0xC0); 
                        cursor();
                    letteranswer=0;
                 }
                 else if(adcvalue>=341 && adcvalue< 682){ //if adc value < thresh
                     send8toLCD(0xC5); 
                     cursor();
                    letteranswer =1;
                 }
                 else if(adcvalue>=682){ //if adc value < thresh
                        send8toLCD(0xCB); 
                        cursor();
                        letteranswer=2;
                 }
                  if (!button){
                    __delay_ms(10);
                     goto check;
                    }
                 }
             }
               
        check:
         if(letteranswer == correctletter &&  mode==2){// 
            if (operation==0){ //addition
            score = score+1;
            }
            else if (operation==1){//subtraction
            score = score+2;
            }
            else if (operation==2){// multiplication
            score = score+3;
            }
            else{}
            goto gamemode2;
         }  
        else if(result == answer &&  mode==1){//figure this out
            if (operation==0){ //addition
            score = score+1;
            }
            else if (operation==1){//subtraction
            score = score+2;
            }
            else if (operation==2){// multiplication
            score = score+3;
            }
            else{}
            goto gamemode1;
         }
        else{
            if (mode==1)
            {goto gamemode1;}
            else{goto gamemode2;}
        }
         gameover:
            clear();
            send8toLCD(0xC);//remove cursor
            sprintf(buffer,"   Score: %d",score);
            string("   GAME OVER!");
            newline();
            string(buffer);
            LED_2 = 0;
            __delay_ms(1100); //5 second delay
            LED_2 =1;
            goto gamestart;
      return 0;
}
void number (int buff){
    int ones;
    int tens;
    int hundreds;
    int thousands;
    
    thousands = buff/1000;
    
    hundreds = buff - thousands*1000;
    hundreds = hundreds/100;
    
    tens = buff - thousands*1000;
    tens = tens - hundreds*100;
    tens = tens/10;
    
    ones = buff - thousands*1000;
    ones = ones - hundreds*100;
    ones = ones - tens*10;
    
    thousands = thousands | 0x30;
    hundreds = hundreds | 0x30;
    tens = tens | 0x30;
    ones = ones | 0x30;
    
    LCDcmd(thousands);
    LCDcmd(hundreds);
    LCDcmd(tens);
    LCDcmd(ones);
    
    return;
}
void ADC_init(){
    //AD1PCFG = 0xFDFF;    //AN9 IS SET TO HAVE ANALOG INPUT
    AD1CON1=0x20E6;
    AD1CON2=0x0000;
    AD1CON3=0x0201;
    AD1CHS=0x0009;
    AD1CSSL=0x0000;  
    //setup ADC configuration bits and TRISB
}
void delay_15 (void){ //15ms
    int k=0;
    while (k < 1880)
    k = k + 1;
    return;
}
void delay340us (void){ //340us
    int k=0;
    while (k < 1880)
    k = k + 1;
    return;
}
void send4toLCD (int w){
    
    LATB = 0x0000;
    Nop();
    //w=w<<8;        
    w = w & 0x000F;
    w = w | 0x0020;
    w = LATB | w;
    LATB = w;

    delay_15();
    LATBbits.LATB5 = 0;
    return;
}
void send8toLCD (int x){
    int y;
    LATB = 0x0000;
    Nop();
    //x=x<<4;  
    y = x & 0x00F0;
    y = y >> 4;
    y = y | 0x0020;
    y = LATB | y;
    LATB = y;
    delay340us();
    LATBbits.LATB5 = 0;
    
    
    LATB = 0x0000;
    Nop();
    //x=x>>4;       
    y = x & 0x000F;
    y = y | 0x0020;
    y = LATB | y;
    LATB = y;
    delay340us();
    LATBbits.LATB5 = 0;
    return;
}
void LCD (void) {       
    delay_15();
    delay_15();
    delay_15();
    
    w = 0x3;
    send4toLCD(w);

    
    w = 0x3;
    send4toLCD(w);

    
    w = 0x3;
    send4toLCD(w);

    
    ///////////////
    
    w = 0x2;
    send4toLCD(w);
  
    
    ////////////////////
    
    //Function set 
    x = 0x28;
    send8toLCD(x); 
   
    
    //Display off
    x = 0x08;
    send8toLCD(x);
    
    
    //Clear Display
    x = 0x01;
    send8toLCD(x);
    
  
    //Entry mode
    x = 0x06;
    send8toLCD(x);
  
    
    //Display On
    x = 0x0C;
    send8toLCD(x);
    
    return;
    
}
void LCDcmd(int z){
    int u;
    LATB = 0x0000;
    Nop();
    //x=x<<4;  
    u = z & 0x00F0;
    u = u >> 4;
    u = u | 0x0030;
    LATB = u;
    delay340us();
    LATBbits.LATB5 = 0;
    
    
    Nop();
    //x=x<<4;       
    u = z & 0x000F;
    u = u | 0x0030;    
    LATB = u;
    delay340us();
    LATBbits.LATB5 = 0;
    LATBbits.LATB4 = 0;
    return;    
}
void string (char* buf){
    int a = 0;
    int b = 0;
    int c = 0;
    
    a = strlen(buf);
    
    while (b < a){
        c = buf[b];
        b = b+1;
        LCDcmd(c);
    }   
    return;
}
void firstline (void){
    send8toLCD(0x80);
}
void newline (void){
    send8toLCD(0xC0);
}
void clear (void){
    send8toLCD(0x01);
}
void cursor (void){
    send8toLCD(0xE);
}

void __attribute__ ((interrupt, no_auto_psv)) _ADC1Interrupt(void){
IEC0bits.AD1IE=0;//Disable interrupt
IFS0bits.AD1IF=0;//Clear flag
adcvalue = ADC1BUF0; //Copy ADC output to adcvalue
IEC0bits.AD1IE=1;//Enable interrupt
IFS0bits.AD1IF=0;//Clear flag
}
void __attribute__((interrupt)) _CNInterrupt(void){
    int deb_ctr = 0;
    
     LATBbits.LATB7 = 1;
    //delay()
    LATBbits.LATB8 = 1;
    //delay();
    LATBbits.LATB9 = 0;
    //delay();
    if(!PORTAbits.RA1){
        while((!PORTAbits.RA1)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
        if(deb_ctr == DEBOUNCEMAX){
            key=3;
        }
        else{
            key=0;
        }
        goto back;
    }
    if(!PORTAbits.RA2){
        while((!PORTAbits.RA2)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
         if(deb_ctr == DEBOUNCEMAX){
            key=6;
        }
        else{
            key=0;
        }
        goto back;
    }
     if(!PORTAbits.RA3){
        while((!PORTAbits.RA3)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
       if(deb_ctr == DEBOUNCEMAX){
            key=9;
        }
        else{
            key=0;
        }
        goto back;
    }
     if(!PORTAbits.RA4){
        while((!PORTAbits.RA4)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
        if(deb_ctr == DEBOUNCEMAX){
            key=12;
        }
        else{
            key=0;
        }
        goto back;
    }
    LATBbits.LATB7 = 0;
    LATBbits.LATB8 = 1;
    LATBbits.LATB9 = 1;
    
    if(!PORTAbits.RA1){
        while((!PORTAbits.RA1)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
        if(deb_ctr == DEBOUNCEMAX){
            key=1;
        }
        else{
            key=0;
        }
        goto back;
    }
      if(!PORTAbits.RA2){
        while((!PORTAbits.RA2)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
         if(deb_ctr == DEBOUNCEMAX){
            key=4;
        }
        else{
            key=0;
        }
        goto back;
    }
      if(!PORTAbits.RA3){
        while((!PORTAbits.RA3)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
       if(deb_ctr == DEBOUNCEMAX){
            key=7;
        }
        else{
            key=0;
        }
        goto back;
    }
     if(!PORTAbits.RA4){
        while((!PORTAbits.RA4)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
        if(deb_ctr == DEBOUNCEMAX){
            key=10;
        }
        else{
            key=0;
        }
        goto back;
    }
    
    LATBbits.LATB7 = 1;
    LATBbits.LATB8 = 0;
    LATBbits.LATB9 = 1;
    //delay();
    
    if(!PORTAbits.RA1){
        while((!PORTAbits.RA1)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
       if(deb_ctr == DEBOUNCEMAX){
            key=2;
        }
        else{
            key=0;
        }
        goto back;
    }
     if(!PORTAbits.RA2){
        while((!PORTAbits.RA2)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
         if(deb_ctr == DEBOUNCEMAX){
            key=5;
        }
        else{
            key=0;
        }
        goto back;
    }
      if(!PORTAbits.RA3){
        while((!PORTAbits.RA3)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
       if(deb_ctr == DEBOUNCEMAX){
            key=8;
        }
        else{
            key=0;
        }
        goto back;
    }
     if(!PORTAbits.RA4){
        while((!PORTAbits.RA4)&&(deb_ctr<DEBOUNCEMAX)){
            deb_ctr++;
        }
        
        if(deb_ctr == DEBOUNCEMAX){
            key=11; //for 0
        }
        else{
            key=0;
        }
        goto back;
    }
   LATBbits.LATB7 = 1;
    LATBbits.LATB8 = 1;
    LATBbits.LATB9 = 0;
   
    
    back:
        IFS1bits.CNIF = 0; //clear IRQ flag
        LATBbits.LATB7 = 0; //pull down all
        LATBbits.LATB8 = 0;
        LATBbits.LATB9 = 0;
        keypadpress=1;
        __delay_ms(1);
}
void __attribute__((__interrupt__, auto_psv)) _T1Interrupt(void)
  {

   IFS0bits.T1IF = 0;   //reset the interrupt flag 
   second =second+1;
       if(second == timelimit)
       {
             second = 0;
             endgameflag = 1;
      }
 }
void TimerInit(void)
{
   IEC0bits.T1IE = 0;      /* Disable Timer1 interrupt */
    T1CON = 0;              /* Disable Timer */
    T1CONbits.TCS = 0;      /* Instruction cycle clock */
    T1CONbits.TGATE = 0;    /* Disable Gated Timer mode */
    T1CONbits.TCKPS = 0b11; /* Select 1:256 Prescaler */
    T1CONbits.TSYNC = 1;    /* Synchronize external clock input */
    TMR1 = 0;               /* Clear timer register */
    PR1 = 60000;  /* Load the timer reset count value */
    IPC0bits.T1IP = 0x04;   /* Set Timer1 Interrupt Priority Level */
    IFS0bits.T1IF = 0;      /* Clear Timer1 Interrupt Flag */
    IEC0bits.T1IE = 1;      /* Enable Timer1 interrupt */
    T1CONbits.TON = 1;      /* Start Timer */

 }
void initgamevar(void){
        score=0;
        second=0;
        keypadpress=0;
        endgameflag = 0;
        wrongchoice[0]=4;
        wrongchoice[1]=4;
        correctletter=4;
        letteranswer=4;
        diff=0;
        answer=100;
        LED_2 =1;
        endgameflag=0;
        timelimit = 0;
        mode=0;
        inputs[0] = 1;
        inputs[1] = 0;
        inputs[2] = 0;
}
int arraytoint(int* buf){
    int integerval = 0;
    integerval = buf[0]*((buf[1]*10)+buf[2]); //sign , tens, ones
    return integerval;
}